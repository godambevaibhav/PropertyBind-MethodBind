import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  // Need to add decorator when we passing the value from child to parent component
  // @Output is decorator
  // itemAddedEvent is EventEmitter name of child component
  // Syntax for EventEmitter : 
  // EventEmitter_Name = new new EventEmitter<{ properties that we want to emit }>()
  @Output () 
  itemAddedEvent = new EventEmitter<{ name: string, price: string, desc: string }>()

 itemName: string;
 itemPrice: string;
 itemDesc: string;

 constructor() { }

  ngOnInit() {
  }

  // onSubmit method is call emit method 
  onSubmit() {
    this.itemAddedEvent.emit({
      name: this.itemName,
      price: this.itemPrice,
      desc: this.itemDesc
    });
  }

}
