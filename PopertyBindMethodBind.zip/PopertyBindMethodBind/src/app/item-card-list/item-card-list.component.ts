import { Component, OnInit, Input , Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-item-card-list',
  templateUrl: './item-card-list.component.html',
  styleUrls: ['./item-card-list.component.css']
})
export class ItemCardListComponent implements OnInit {

  // Need to add decorator when we accepting the value from parent component
  // @Input is decorator
  // itemCard is the child component property to it accept parent items data to bind data
  @Input()
  itemCard: { name: string, price: string, desc: string };
 
  @Input()
  dataCardId: number;

  @Output () 
  itemDataCardId = new EventEmitter<number>()


  constructor() { }

  ngOnInit() {
  }

  onRemove(){
     this.itemDataCardId.emit(this.dataCardId);
  }

}
