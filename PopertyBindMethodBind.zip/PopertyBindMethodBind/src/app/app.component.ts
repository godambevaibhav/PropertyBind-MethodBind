import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  // Array need to be intitialize
  // Syntax  to define array :
  // Array_name  : { Property of arrays } [] = [];<= // uasing this way can intitialize the array  
  items: { name: string, price: string, desc: string } [] = [];

  constructor(){
    // Need to push array items 
    this.items.push({name:'Mobiles', price: '10,000', desc: 'Mobile description'});
  }

  updateItems(itemAdded :{ name: string, price: string, desc: string }) {
    this.items.push(itemAdded);
  }

  removeDataCardItems(cardId){
    console.log(cardId);
  this.items.splice(cardId,1);
  }

}
